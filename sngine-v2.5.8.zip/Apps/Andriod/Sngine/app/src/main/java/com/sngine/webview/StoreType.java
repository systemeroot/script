package com.sngine.webview;

public enum StoreType {
    GOOGLEPLAY,
    AMAZON
}
