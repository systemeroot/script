//
//  main.m
//  webApp
//
//  Created by ali fouad srhan on 4/25/16.
//  Copyright (c) 2016 ali fouad srhan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
