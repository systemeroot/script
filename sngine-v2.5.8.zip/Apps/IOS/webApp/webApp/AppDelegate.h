//
//  AppDelegate.h
//  webApp
//
//  Created by ali fouad srhan on 4/25/16.
//  Copyright (c) 2016 ali fouad srhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

